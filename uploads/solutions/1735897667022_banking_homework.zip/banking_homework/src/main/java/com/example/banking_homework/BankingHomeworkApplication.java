package com.example.banking_homework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingHomeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingHomeworkApplication.class, args);
	}

}
