package com.example.banking_homework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingHomeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
